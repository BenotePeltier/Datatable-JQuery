$(document).ready(function() {
    tableView('table1');

    $('#table1').show();
    $('#table2').hide();
    $('#table3').hide();

    $('#datatable_style').change(function() {
        var val = $(this).val();
        if (val == "default") {
            tableView('table1');
            $('#table1').show();
            $('#table2').hide();
            $('#table3').hide();
        } else if (val == "border") {
            tableView('table2');
            $('#table1').hide();
            $('#table2').show();
            $('#table3').hide();
        } else if (val == "striped") {
            tableView('table3');
            $('#table1').hide();
            $('#table2').hide();
            $('#table3').show();
        }

        location.reload();
    })
});

function tableView(src) {
    var table = $('#' + src).DataTable({
        "aLengthMenu": [
            [5, 25, 50, 75, -1],
            [5, 25, 50, 75, "All"]
        ],
        "pageLength": 5,
        dom: 'lBfrtip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5', {
                extend: 'print',
                customize: function(win) {
                    $(win.document.body)
                        .css('font-size', '10pt')
                        .prepend(
                            '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
                        );

                    $(win.document.body).find('table')
                        .addClass('compact')
                        .css('font-size', 'inherit');
                }
            }
        ],
        "scrollY": 200,
        "scrollX": true
    });

}